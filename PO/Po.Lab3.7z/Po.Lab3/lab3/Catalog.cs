﻿namespace lab3
{
    public class Catalog
    {
        IList<Item>? Items
        { get; set; }

    }
}
