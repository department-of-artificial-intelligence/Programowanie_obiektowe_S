﻿namespace Lab5.BLL
{
    public class Bird : Animal
    {
        public double _wingspan;
        public double _flyEndurance;


    }
}