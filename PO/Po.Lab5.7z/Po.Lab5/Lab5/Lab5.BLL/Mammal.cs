﻿namespace Lab5.BLL
{
    public class Mammal : Animal
    {
        public string name;
        Mammal()
            : base()
        {
            name = "d";
        }
    }
}