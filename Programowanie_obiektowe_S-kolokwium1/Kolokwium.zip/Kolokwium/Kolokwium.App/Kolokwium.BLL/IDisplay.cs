﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokwium.BLL
{
    public interface IDisplay
    {
        public void Display()
        {
            Console.WriteLine("");
        }
    }
}
