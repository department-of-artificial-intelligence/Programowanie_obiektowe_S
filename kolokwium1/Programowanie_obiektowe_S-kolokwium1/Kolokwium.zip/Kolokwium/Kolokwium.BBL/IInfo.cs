﻿namespace Kolokwium.BBL
{
    public interface IInfo
    {
        void Display();
    }
}
